# memecrypto by @SciresM

**Dependencies:**

SHA1 implementation taken from [libsha1](https://github.com/dottedmag/libsha1)

AES-ECB implementation taken from [tiny-AES128-C](https://github.com/kokke/tiny-AES128-C)

RSA implementation based on [mini-gmp](https://gmplib.org/)

**Licensing:**

This software is licensed under the terms of the GPLv3.  
You can find a copy of the license in the LICENSE file.
